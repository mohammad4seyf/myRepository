package com.example.springbootexample.Service;

public interface crudImpl {
    


}
